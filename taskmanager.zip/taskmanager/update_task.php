<?php
session_start();
include('includes/db.php');
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if (isset($_GET['id'])) {
    $task_id = $_GET['id'];
    $sql = "SELECT * FROM tasks WHERE id = '$task_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $task = $result->fetch_assoc();
    } else {
        echo "Task not found.";
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $status = $_POST['status'];

    $sql = "UPDATE tasks SET title = '$title', description = '$description', status = '$status' WHERE id = '$task_id'";

    if ($conn->query($sql) === TRUE) {
        header('Location: tasks.php');
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Task</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    margin: 20px;
    background-color: #f9f9f9;
}

h2 {
    color: #333;
}

.task-form {
    max-width: 500px;
    margin: 0 auto;
    padding: 20px;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.task-form label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

.task-form input[type="text"],
.task-form textarea,
.task-form select {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px;
}

.task-form button.btn {
    display: inline-block;
    padding: 10px 15px;
    background-color: #007BFF;
    color: #fff;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

.task-form button.btn:hover {
    background-color: #0056b3;
}
h2{
    text-align: center;
    color: #333;
}
</style>
</head>
<body>
    <h2>Update Task</h2>
    <form method="POST" class="task-form">
        <label for="title">Task Title:</label>
        <input type="text" id="title" name="title" value="<?php echo $task['title']; ?>" required><br>

        <label for="description">Description:</label>
        <textarea id="description" name="description" required><?php echo $task['description']; ?></textarea><br>

        <label for="status">Status:</label>
        <select id="status" name="status">
            <option value="pending" <?php echo ($task['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
            <option value="completed" <?php echo ($task['status'] == 'completed') ? 'selected' : ''; ?>>Completed</option>
        </select><br>

        <button type="submit" class="btn">Update Task</button>
    </form>
</body>
</html>