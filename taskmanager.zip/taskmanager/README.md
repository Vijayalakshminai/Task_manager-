# Task Manager Application (LAMP Stack)

## Features
- User Signup & Login
- Task CRUD Operations
- Categories/Tags
- Responsive Design

## Tech Stack
- Linux (Ubuntu)
- Apache
- MySQL
- PHP

## Setup Instructions
1. Clone the repository.
2. Install Apache, MySQL, PHP.
3. Place the code in `/var/www/html/`.
4. Import the MySQL database:


## Local usage
1. Start Apache: `sudo apachectl start`
2. Open your browser: `http://localhost/<project name>`