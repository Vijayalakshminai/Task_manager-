<?php
session_start();
include('includes/db.php');
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}


$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM tasks WHERE user_id = '$user_id'";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Tasks</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    margin: 20px;
    background-color: #f9f9f9;
}

h2 {
    color: #333;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 10px;
    text-align: left;
}

th {
    background-color: #f4f4f4;
}

tr:nth-child(even) {
    background-color: #f9f9f9;
}

tr:hover {
    background-color: #f1f1f1;
}

a {
    color: #007BFF;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

.create-task {
    display: inline-block;
    margin-top: 20px;
    padding: 10px 15px;
    background-color: #007BFF;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
}

.create-task:hover {
    background-color: #0056b3;
}
h2{
    text-align: center;
    color: #333;
}
button {
    background-color: #007BFF;
    color: #fff;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin: 10px 0;
    display: block;
    width: 100px;
    text-align: center;
}
button a {
    color: #fff;
    text-decoration: none;
}
    </style>
</head>
<body>
<button><a href="logout.php">Logout</a></button>
<a href="create_task.php" class="create-task">Create New Task</a>
    <h2>My Tasks</h2>
    <table>
        <tr>
            <th>Title</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php while ($task = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $task['title']; ?></td>
            <td><?php echo $task['status']; ?></td>
            <td>
                <a href="update_task.php?id=<?php echo $task['id']; ?>">Edit</a> |
                <a href="delete_task.php?id=<?php echo $task['id']; ?>">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    
</body>
</html>