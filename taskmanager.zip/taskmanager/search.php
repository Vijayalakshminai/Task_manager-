<?php
session_start();
include('includes/db.php');
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $search = $_POST['search'];

    $sql = "SELECT * FROM tasks WHERE title LIKE '%$search%' AND user_id = '{$_SESSION['user_id']}'";
    $result = $conn->query($sql);

    echo "<h2>Search Results</h2>";
    echo "<table><tr><th>Title</th><th>Status</th><th>Actions</th></tr>";

    while ($task = $result->fetch_assoc()) {
        echo "<tr><td>" . $task['title'] . "</td><td>" . $task['status'] . "</td><td>
            <a href='update_task.php?id=" . $task['id'] . "'>Edit</a> |
            <a href='delete_task.php?id=" . $task['id'] . "'>Delete</a></td></tr>";
    }

    echo "</table>";
}
?>

<form method="POST">
    Search Tasks: <input type="text" name="search">
    <button type="submit">Search</button>
</form>
